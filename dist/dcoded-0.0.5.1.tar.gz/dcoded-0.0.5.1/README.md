# dcoded

Welcome to dcoded - the package designed to do everything!

## Installation

Linux / macOS (python3):

``` zsh
python3 -m pip install dcoded
```

Linux  / macOS (python2):

``` zsh
python -m pip install dcoded
```

Windows:

``` zsh
py -m pip install dcoded
```

## Modules

Below are listed the modules in dcoded:

* dcoded.io.file

## Docs

[dcode documentation](https://github.com/dylanopen/dcoded/blob/main/docs.md)
